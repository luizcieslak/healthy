# Baasbox Javascript SDK

Version 0.1

- Login
- Load document
- Loadd JSON asset
- Create new user

Version 0.2

- Added cookie support
- Added `getImageURI()`
- Added end point validation

Version 0.3

- Added callback to login and createUser
- improved getImageURI

Version 0.3.5

- Added support to save/update/delete and updateField

Version 0.3.6

- Added support to Zepto and all permission

Version 0.8.1

- Just a release number update to align this SDK with the other ones

Version 0.8.2

- Added promises

Version 0.8.3

- Added APIs to grant/revoke permissions

Version 0.8.4
- Removed deprecated method for push notifications

